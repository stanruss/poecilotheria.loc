<?php

$_lang['ajaxform_prop_form'] = 'Чанк с формой для отправки.';
$_lang['ajaxform_prop_snippet'] = 'Сниппет, который будет обрабатывать указанную форму.';
$_lang['ajaxform_prop_frontend_css'] = 'Файл с css стилями для подключения на фронтенде.';
$_lang['ajaxform_prop_frontend_js'] = 'Файл с javascript для подключения на фронтенде.';
$_lang['ajaxform_prop_actionUrl'] = 'Коннектор для обработки ajax запросов.';
$_lang['ajaxform_prop_formSelector'] = 'Имя CSS класса, который будеи использован как jQuery селектор для инициализации формы. По умолчанию "ajax_form".';
$_lang['ajaxform_prop_objectName'] = 'Имя объекта для инициализации в подключаемом javascript. По умолчанию "AjaxForm".';